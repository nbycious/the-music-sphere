import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SearchService } from '../search.service';

@Component({
  selector: 'app-resultados',
  templateUrl: './resultados.component.html',
  styleUrls: ['./resultados.component.css']
})
export class ResultadosComponent implements OnInit {

  resultados: any[] = [];
  query: string = "";

  constructor(private route: ActivatedRoute, private searchService: SearchService) { }

  ngOnInit(): void {
   
  }

}
