import { Injectable } from "@angular/core";
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { Observable, forkJoin } from 'rxjs';


@Injectable({
    providedIn: 'root'
  })
  export class SearchService {
    constructor(private firestore: AngularFirestore) {}
  
    buscarProductos(termino: string): Observable<any[]> {
        const CDs = this.firestore.collection('CDs', ref => ref.where('Titulo', '>=', termino).where('Titulo', '<=', termino + '\uf8ff')).valueChanges();
        const vinilos = this.firestore.collection('Vinilos', ref => ref.where('Titulo', '>=', termino).where('Titulo', '<=', termino + '\uf8ff')).valueChanges();
        const merch = this.firestore.collection('Merch', ref => ref.where('Titulo', '>=', termino).where('Titulo', '<=', termino + '\uf8ff')).valueChanges();
    
        return forkJoin([CDs, vinilos, merch]); // Combina las tres observables en una sola
      }
    
  }