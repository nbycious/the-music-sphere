export const environment = {
  production: true,
  firebaseConfig : {

    apiKey: "AIzaSyCno0tv3OYQFu7c6CNAKLnqqQESiugcsPE",
  
    authDomain: "the-musicsphere.firebaseapp.com",
  
    projectId: "the-musicsphere",
  
    storageBucket: "the-musicsphere.appspot.com",
  
    messagingSenderId: "741482338704",
  
    appId: "1:741482338704:web:405caf4a391b00c06e7b15",
  
    measurementId: "G-3KVZ97M75T"
  
  }
  
  
};
