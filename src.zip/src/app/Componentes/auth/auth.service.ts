import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private logueado = new BehaviorSubject<boolean>(false);//loggedIn

  constructor() {
    const user = localStorage.getItem('usuario');
    this.logueado.next(!!user);
  }

  isAuth() {
    return this.logueado.asObservable();
  }

  login(user: any) {
    localStorage.setItem('usuario', JSON.stringify(user));
    this.logueado.next(true);
  }

  logout() {
    localStorage.removeItem('usuario');
    this.logueado.next(false);
  }
}
