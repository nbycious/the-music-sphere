import { Component, OnInit,ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth/auth.service';
//normalmente vacio
@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  usuarioLogueado: boolean = false; //isLoggedIn

  constructor(private router : Router, private refresh: ChangeDetectorRef, private auth : AuthService) { }

  ngOnInit(): void {
    this.auth.isAuth().subscribe(logueado => {
      this.usuarioLogueado = logueado;
    })
    
  }

  cerrarSesion() : void{
    this.auth.logout()
    this.router.navigate(['/'])
  }

  buscar() : void{
    const termBusq = (document.querySelector('.search-bar input') as HTMLInputElement).value;
    if (termBusq) {
      this.router.navigate(['/search'], { queryParams: { q: termBusq } });
    }
  }

}
