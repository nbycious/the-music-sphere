import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { MerchService } from '../../Categorias/merch/merch.service';
import { Mercancia } from 'src/app/Clases/bd2';
import { CartService } from '../../cart/cart.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-detallemerch',
  templateUrl: './detallemerch.component.html',
  styleUrls: ['./detallemerch.component.css']
})
export class DetallemerchComponent implements OnInit {
  mercancia$: Observable<Mercancia> | undefined;

  constructor(
    private route: ActivatedRoute,
    private merchService: MerchService,
    private cartService : CartService,
    private router : Router
  ) { }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.mercancia$ = this.merchService.getMercanciaById(id);
    }
  }

  addToCart(mercancia: Mercancia): void {
    this.cartService.addToCart(mercancia);
    this.router.navigate(['/cart']); // Navega al carrito después de añadir
  }
}
