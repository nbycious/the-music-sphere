import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ViniloService } from '../../Categorias/vinilo/vinilo.service';
import { Vinilos } from 'src/app/Clases/bd2';
import { CartService } from '../../cart/cart.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-detallevinil',
  templateUrl: './detallevinil.component.html',
  styleUrls: ['./detallevinil.component.css']
})
export class DetallevinilComponent implements OnInit {

    vinilo: Vinilos = new Vinilos();
    viniloId:  string | null = null;

  constructor(private route: ActivatedRoute, 
    private viniloService: ViniloService,
    private cartService: CartService,
    private router: Router) { }

  ngOnInit(): void {
    this.viniloId = this.route.snapshot.paramMap.get('id');
    if (this.viniloId) {
      this.viniloService.getViniloById(this.viniloId).subscribe(data => {
        this.vinilo.setData(data);
      });
    }
  }
  addToCart() {
    this.cartService.addToCart(this.vinilo);/*funciona correctamente*/ 
    alert('Producto añadido al carrito');
    this.router.navigate(['/cart']);
  }
  }


