import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DiscoService } from '../../Categorias/cd/disco.service';
import { Disco } from 'src/app/Clases/bd2';
import { CartService } from '../../cart/cart.service';
import { Router } from '@angular/router';
import { NavBarComponent } from '../../nav-bar/nav-bar.component';

@Component({
  selector: 'app-detalleprod',
  templateUrl: './detalleprod.component.html',
  styleUrls: ['./detalleprod.component.css']
})
export class DetalleprodComponent implements OnInit {
  disco: Disco = new Disco();
  discoId: string | null = null;

  constructor(
    private route: ActivatedRoute,
    private discoService: DiscoService,
    private cartService: CartService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.discoId = this.route.snapshot.paramMap.get('id');
    if (this.discoId) {
      this.discoService.getDiscoById(this.discoId).subscribe(data => {
        this.disco.setData(data);
      });
    }
  }

  addToCart(): void { /*funciona correctamente*/ 
    this.cartService.addToCart(this.disco);
    alert('Producto añadido al carrito');
    this.router.navigate(['/cart']);
  }
}
