import { Injectable } from '@angular/core';//Injectable define el servicio
import { Firestore, collectionData, collection, doc, docData } from '@angular/fire/firestore';
import { Observable } from 'rxjs';  // Importa Observable para manejar flujos de datos reactivo
import { Disco } from 'src/app/Clases/bd2';// Importa la clase Disco que define la estructura de un disco

@Injectable({
  providedIn: 'root'
})
export class DiscoService {

  constructor(private firestore: Firestore) {}

  getDiscos(): Observable<Disco[]> {
    const discosCollection = collection(this.firestore, 'CDs');
    return collectionData(discosCollection, { idField: 'DiscoId' }) as Observable<Disco[]>;
  }

  getDiscoById(id: string): Observable<Disco> {
    const discoDoc = doc(this.firestore, `CDs/${id}`);
    return docData(discoDoc, { idField: 'DiscoId' }) as Observable<Disco>;
  }
  
}

